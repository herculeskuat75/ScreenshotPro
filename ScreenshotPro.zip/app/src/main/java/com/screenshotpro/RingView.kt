package com.screenshotpro

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View

class RingView(c: Context) : View(c) {
    private val sp = c.getSharedPreferences("sp", 0)
    private var angle = 0f
    private var last = 0L
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1E88E5.toInt() }
    private val mx = Matrix()
    private var sh: SweepGradient? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sh = SweepGradient(
            w / 2f, h / 2f,
            intArrayOf(0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF1744.toInt()),
            null
        )
        ring.strokeWidth = w * 0.11f
    }

    override fun onDraw(c: Canvas) {
        val s = sh ?: return
        val now = SystemClock.uptimeMillis()
        val dt = minOf(now - last, 100L)
        last = now
        val spd = sp.getInt("spd", 5)
        if (spd > 0) angle = (angle + dt * 360f * spd / 7000f) % 360f
        mx.setRotate(angle, width / 2f, height / 2f)
        s.setLocalMatrix(mx)
        ring.shader = s
        val cx = width / 2f; val cy = height / 2f; val t = ring.strokeWidth
        c.drawCircle(cx, cy, (width - t) / 2f, ring)
        c.drawCircle(cx, cy, (width - 2 * t) / 2f + 1f, disc)
        if (spd > 0) postInvalidateOnAnimation() else postInvalidateDelayed(500)
    }
}
