package com.screenshotpro

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.*
import android.widget.ImageView
import android.widget.FrameLayout
import android.graphics.Typeface
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.abs
import kotlin.math.hypot

class FloatService : Service() {
    companion object { var inst: FloatService? = null }
    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var last: Image? = null
    private var fab: View? = null
    private var fabIcon: View? = null
    private var cdText: TextView? = null
    private var hold: Runnable? = null
    private var panel: LinearLayout? = null
    private var glow: GlowView? = null
    private val st = Util.Stitcher()
    private var useA11y = false
    private val h = Handler(Looper.getMainLooper())
    private var W = 0
    private var H = 0
    private var D = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() { super.onCreate(); inst = this }

    private fun setupWm() {
        val a = A11yService.inst
        useA11y = a != null
        wm = (a ?: this).getSystemService(WINDOW_SERVICE) as WindowManager
    }

    private fun removeAllViews() {
        removeGlow(); hideX()
        try { fab?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        fab = null; panel = null
    }

    // dipanggil saat aksesibilitas diaktifkan/dimatikan: bangun ulang overlay dengan WindowManager yang sesuai
    fun refreshOverlay() {
        if (proj == null || !::wm.isInitialized) return
        if (useA11y == (A11yService.inst != null)) return
        removeAllViews()
        try { setupWm(); addFab() } catch (e: Exception) { toast("Overlay gagal: ${e.message}") }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sp", "Screenshot Pro", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "sp").setSmallIcon(R.drawable.ic_camera).setContentTitle("Screenshot Pro aktif").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
        if (i == null || proj != null) return START_NOT_STICKY
        val data = i.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            setupWm()
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            W = dm.widthPixels; H = dm.heightPixels; D = dm.densityDpi
            val p = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(i.getIntExtra("code", 0), data)
            proj = p
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
            val r = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 3)
            reader = r
            r.setOnImageAvailableListener({ rd -> rd.acquireLatestImage()?.let { last?.close(); last = it } }, h)
            vd = p.createVirtualDisplay("sp", W, H, D, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h)
            addFab()
        } catch (e: Exception) {
            toast("Gagal memulai: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private var xv: TextView? = null

    private fun checkX(cx: Int, cy: Int, dm: DisplayMetrics): Boolean {
        if (xv == null) {
            val t = TextView(this).apply {
                text = "✕"; setTextColor(Color.WHITE); textSize = 26f; gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCCD32F2F.toInt()) }
            }
            val p = dp(64)
            val l = WindowManager.LayoutParams(
                p, p, ovType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(56) }
            wm.addView(t, l)
            xv = t
        }
        val tx = dm.widthPixels / 2; val ty = dm.heightPixels - dp(56) - dp(32)
        val near = hypot((cx - tx).toDouble(), (cy - ty).toDouble()) < dp(80)
        val k = if (near) 1.4f else 1f
        xv?.scaleX = k; xv?.scaleY = k
        return near
    }

    private fun hideX() {
        xv?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        xv = null
    }

    private fun ovType() = if (useA11y) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun lp(w: Int, hh: Int) = WindowManager.LayoutParams(
        w, hh, ovType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    )

    private fun addFab() {
        val s = dp(60)
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.ic_camera)
            setPadding(dp(17), dp(17), dp(17), dp(17))
        }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 24f; gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD); visibility = View.GONE
        }
        val v = FrameLayout(this).apply {
            addView(RingView(this@FloatService), FrameLayout.LayoutParams(-1, -1))
            addView(iv, FrameLayout.LayoutParams(-1, -1))
            addView(tv, FrameLayout.LayoutParams(-1, -1))
            alpha = 0.9f
        }
        fabIcon = iv; cdText = tv
        val l = lp(s, s).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = H / 3 }
        l.flags = l.flags or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0; var moved = false; var near = false; var fired = false; var t0 = 0L; var d = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = l.x; oy = l.y; moved = false; fired = false; near = false
                    d = getSharedPreferences("sp", 0).getInt("delay", 0)
                    t0 = SystemClock.uptimeMillis()
                    if (d > 0) {
                        val r = object : Runnable {
                            override fun run() {
                                val el = SystemClock.uptimeMillis() - t0
                                val rem = d * 100L - el
                                if (rem <= 0) { fired = true; cancelHold(); doCapture() }
                                else {
                                    if (el >= 400) {
                                        cdText?.text = ((rem + 999) / 1000).toString()
                                        cdText?.visibility = View.VISIBLE; fabIcon?.visibility = View.INVISIBLE
                                    }
                                    h.postDelayed(this, 100)
                                }
                            }
                        }
                        hold = r; h.postDelayed(r, 100)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (abs(mx) > 8 || abs(my) > 8) { moved = true; cancelHold() }
                    if (moved) { val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm); l.x = (ox + mx).toInt().coerceIn(0, dm.widthPixels - s); l.y = (oy + my).toInt().coerceIn(0, dm.heightPixels - s); wm.updateViewLayout(v, l); near = checkX(l.x + s / 2, l.y + s / 2, dm) }
                }
                MotionEvent.ACTION_UP -> {
                    cancelHold()
                    val close = moved && near
                    hideX()
                    if (close) stopSelf() else if (!moved && d <= 0) doCapture()
                }
                MotionEvent.ACTION_CANCEL -> { cancelHold(); hideX() }
            }
            true
        }
        wm.addView(v, l)
        fab = v
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun cancelHold() {
        hold?.let { h.removeCallbacks(it) }
        hold = null
        cdText?.visibility = View.GONE; fabIcon?.visibility = View.VISIBLE
    }

    private fun doCapture() {
        removeGlow()
        fab?.visibility = View.INVISIBLE
        panel?.visibility = View.GONE
        h.postDelayed({
            val im = last
            if (im == null) {
                toast("Gagal mengambil layar")
            } else {
                val msg = try { st.add(Util.toBitmap(im)) } catch (e: Throwable) { "Gagal menyambung: ${e.message}" }
                if (msg != null) toast(msg)
                showPanel()
                showGlow()
            }
            fab?.visibility = View.VISIBLE
        }, 400)
    }

    private fun showGlow() {
        removeGlow()
        val g = GlowView(this)
        val l = WindowManager.LayoutParams(
            W, H, ovType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(g, l)
        glow = g
        g.play { if (glow === g) removeGlow() }
    }

    private fun removeGlow() {
        glow?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        glow = null
    }

    private fun showPanel() {
        if (panel == null) {
            val ll = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(0xEE222222.toInt()) }
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }
            fun item(t: String, a: () -> Unit) = ll.addView(TextView(this).apply {
                text = t; setTextColor(Color.WHITE); textSize = 15f
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { a() }
            })
            item("Panjang ↓") { panel?.visibility = View.GONE; toast("Scroll layar, lalu tekan kamera lagi") }
            item("Potong/Edit") {
                val b = st.result(); st.reset(); panel?.visibility = View.GONE
                if (b != null) Thread {
                    val f = File(cacheDir, "edit.png")
                    Util.writePng(b, f)
                    h.post { startActivity(Intent(this, EditorActivity::class.java).putExtra("p", f.path).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }.start()
            }
            item("Simpan") {
                val b = st.result(); st.reset(); panel?.visibility = View.GONE
                if (b != null) Util.save(this, b) { toast(it) }
            }
            item("Batal") { st.reset(); panel?.visibility = View.GONE }
            val l = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
                .apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(90) }
            wm.addView(ll, l)
            panel = ll
        }
        panel?.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        inst = null
        if (::wm.isInitialized) removeAllViews()
        try { last?.close(); vd?.release(); reader?.close(); proj?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }
}
