package com.screenshotpro

import android.content.Context
import android.graphics.*
import android.media.Image
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import java.io.File

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

object Util {
    fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val bw = p.rowStride / p.pixelStride
        val b = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        b.copyPixelsFromBuffer(p.buffer)
        return if (bw == img.width) b else Bitmap.createBitmap(b, 0, 0, img.width, img.height)
    }

    class Stitcher {
        private val strips = ArrayList<Bitmap>()
        private var footer: Bitmap? = null
        private var pHash: LongArray? = null
        private var w = 0
        private var h = 0
        private var accEnd = 0
        private var total = 0
        private var trimmed = false

        fun isEmpty() = strips.isEmpty()
        fun reset() { strips.clear(); footer = null; pHash = null; trimmed = false; total = 0; accEnd = 0 }

        private fun hashes(b: Bitmap, inf: BooleanArray): LongArray {
            val ww = b.width; val hh = b.height
            val row = IntArray(ww)
            val r = LongArray(hh)
            for (y in 0 until hh) {
                b.getPixels(row, 0, ww, 0, y, ww, 1)
                var hs = 1125899906842597L; var first = row[0] and 0xF8F8F8; var varied = false
                var x = 0
                while (x < ww) {
                    val p = row[x] and 0xF8F8F8
                    if (p != first) varied = true
                    hs = hs * 31 + p
                    x += 3
                }
                r[y] = hs; inf[y] = varied
            }
            return r
        }

        private fun crop(n: Bitmap, y: Int, len: Int): Bitmap {
            val o = Bitmap.createBitmap(n.width, len, Bitmap.Config.ARGB_8888)
            Canvas(o).drawBitmap(n, Rect(0, y, n.width, y + len), Rect(0, 0, n.width, len), null)
            return o
        }

        // return null kalau sukses, atau pesan error
        fun add(n: Bitmap): String? {
            if (strips.isEmpty()) {
                strips.add(n); w = n.width; h = n.height; total = h; accEnd = h
                val inf = BooleanArray(h); pHash = hashes(n, inf)
                return null
            }
            if (n.width != w || n.height != h) { n.recycle(); return "Ukuran layar berubah" }
            val ra = pHash!!
            val inf = BooleanArray(h)
            val rb = hashes(n, inf)
            var same = 0
            for (y in 0 until h) if (rb[y] == ra[y]) same++
            if (same > h * 0.97) { n.recycle(); return "Layar belum bergeser, scroll dulu" }
            var best = 0; var bc = 0
            val maxD = (h * 0.92f).toInt()
            for (d in 1 until maxD) {
                var c = 0
                for (y in 0 until h - d) if (inf[y] && rb[y] == ra[y + d]) c++
                if (c > bc) { bc = c; best = d }
            }
            if (best == 0 || bc < 8) { n.recycle(); return "Gagal menyambung, scroll lebih pelan" }
            var fb = 0
            val cap = h / 4
            while (fb < cap && rb[h - 1 - fb] == ra[h - 1 - fb]) fb++
            val f = h - fb
            if (!trimmed) {
                val s0 = strips[0]
                val t = crop(s0, 0, f)
                s0.recycle(); strips[0] = t
                total = f; accEnd = f; trimmed = true
            }
            val start = maxOf(accEnd - best, 0)
            val len = f - start
            if (len > 0) {
                if (total + len > 30000) { n.recycle(); return "Batas tinggi screenshot tercapai" }
                strips.add(crop(n, start, len)); total += len
            }
            accEnd = maxOf(f, accEnd - best)
            footer = if (fb > 0) crop(n, f, fb) else null
            pHash = rb
            n.recycle()
            return null
        }

        fun result(): Bitmap? {
            if (strips.isEmpty()) return null
            val f = footer
            if (strips.size == 1 && f == null) return strips[0]
            val th = total + (f?.height ?: 0)
            val out = Bitmap.createBitmap(w, th, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            var y = 0f
            for (s in strips) { c.drawBitmap(s, 0f, y, null); y += s.height }
            if (f != null) c.drawBitmap(f, 0f, y, null)
            return out
        }
    }

    fun writePng(b: Bitmap, f: File) {
        f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun save(c: Context, b: Bitmap, done: (String) -> Unit) {
        val ctx = c.applicationContext
        Thread {
            val msg = try {
                val sp = ctx.getSharedPreferences("sp", 0)
                val tree = Uri.parse(sp.getString("dir", null)!!)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                val n = sp.getInt("n", 0) + 1
                val uri = DocumentsContract.createDocument(ctx.contentResolver, parent, "image/png", "screenshot $n")!!
                ctx.contentResolver.openOutputStream(uri)!!.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                sp.edit().putInt("n", n).apply()
                "Tersimpan: screenshot $n"
            } catch (e: Exception) {
                "Gagal simpan: ${e.message}"
            }
            Handler(Looper.getMainLooper()).post { done(msg) }
        }.start()
    }
}
