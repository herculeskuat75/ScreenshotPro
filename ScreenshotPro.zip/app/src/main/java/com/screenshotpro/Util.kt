package com.screenshotpro

import android.content.Context
import android.graphics.*
import android.media.Image
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import java.io.File

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

object Util {
    fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val bw = p.rowStride / p.pixelStride
        val b = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        b.copyPixelsFromBuffer(p.buffer)
        return if (bw == img.width) b else Bitmap.createBitmap(b, 0, 0, img.width, img.height)
    }

    fun stitch(a: Bitmap, n: Bitmap): Bitmap {
        val w = n.width; val nh = n.height; val ah = a.height
        if (a.width != w || ah + nh > 60000) return a
        val th = 8
        var ty = -1
        var t: Array<IntArray>? = null
        for (f in floatArrayOf(0.3f, 0.45f, 0.6f, 0.75f, 0.15f)) {
            val y0 = (nh * f).toInt()
            val tt = Array(th) { k -> IntArray(w).also { r -> n.getPixels(r, 0, w, 0, y0 + k, w, 1) } }
            var diff = 0
            for (r in tt) { var x = 0; while (x < w) { if (r[x] != tt[0][0]) diff++; x += 4 } }
            if (diff > (w / 4) * th / 10) { ty = y0; t = tt; break }
        }
        var s = nh
        if (t != null) {
            val row = IntArray(w)
            val base = ah - nh + ty
            var y = base + 4
            while (y <= ah - th) {
                var ok = true
                var k = 0
                while (k < th && ok) {
                    a.getPixels(row, 0, w, 0, y + k, w, 1)
                    var bad = 0; var cnt = 0; var x = 0
                    while (x < w) { if (row[x] != t[k][x]) bad++; cnt++; x += 3 }
                    if (bad * 50 > cnt) ok = false
                    k++
                }
                if (ok) { s = y - base; break }
                y++
            }
        }
        val r = Bitmap.createBitmap(w, ah + s, Bitmap.Config.ARGB_8888)
        val c = Canvas(r)
        c.drawBitmap(a, 0f, 0f, null)
        c.drawBitmap(n, Rect(0, nh - s, w, nh), Rect(0, ah, w, ah + s), null)
        return r
    }

    fun writePng(b: Bitmap, f: File) {
        f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun save(c: Context, b: Bitmap, done: (String) -> Unit) {
        val ctx = c.applicationContext
        Thread {
            val msg = try {
                val sp = ctx.getSharedPreferences("sp", 0)
                val tree = Uri.parse(sp.getString("dir", null)!!)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                val n = sp.getInt("n", 0) + 1
                val uri = DocumentsContract.createDocument(ctx.contentResolver, parent, "image/png", "screenshot $n")!!
                ctx.contentResolver.openOutputStream(uri)!!.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                sp.edit().putInt("n", n).apply()
                "Tersimpan: screenshot $n"
            } catch (e: Exception) {
                "Gagal simpan: ${e.message}"
            }
            Handler(Looper.getMainLooper()).post { done(msg) }
        }.start()
    }
}
