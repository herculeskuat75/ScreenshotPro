package com.screenshotpro

import android.content.Context
import android.graphics.*
import android.media.Image
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import java.io.File

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

object Util {
    fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val bw = p.rowStride / p.pixelStride
        val b = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        b.copyPixelsFromBuffer(p.buffer)
        return if (bw == img.width) b else Bitmap.createBitmap(b, 0, 0, img.width, img.height)
    }

    class Stitcher {
        private val strips = ArrayList<Bitmap>()
        private var footer: Bitmap? = null
        private var prev: Bitmap? = null
        private var pHash: LongArray? = null
        private var w = 0
        private var h = 0
        private var accEnd = 0
        private var total = 0
        private var trimmed = false

        private var pSig: ByteArray? = null
        private val SN = 48

        fun isEmpty() = strips.isEmpty()
        fun pieces() = strips.size
        fun reset() { strips.clear(); footer = null; prev = null; pHash = null; pSig = null; trimmed = false; total = 0; accEnd = 0 }

        // tanda tangan baris berbasis luminans (toleran terhadap noise kecil), dipakai bila pencocokan persis gagal
        private fun sigs(b: Bitmap): ByteArray {
            val ww = b.width; val hh = b.height
            val row = IntArray(ww)
            val out = ByteArray(hh * SN)
            val m = minOf(maxOf(ww / 30, 8), ww / 4)
            val span = ww - 2 * m
            for (y in 0 until hh) {
                b.getPixels(row, 0, ww, 0, y, ww, 1)
                for (k in 0 until SN) {
                    val p = row[m + (span - 1) * k / (SN - 1)]
                    val l = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 151 + (p and 255) * 28) shr 8
                    out[y * SN + k] = l.toByte()
                }
            }
            return out
        }

        private fun rowInf(s: ByteArray, y: Int): Boolean {
            var lo = 255; var hi = 0
            for (k in 0 until SN) { val v = s[y * SN + k].toInt() and 255; if (v < lo) lo = v; if (v > hi) hi = v }
            return hi - lo > 24
        }

        private fun rowEq(a: ByteArray, ya: Int, b: ByteArray, yb: Int): Boolean {
            var sum = 0
            val oa = ya * SN; val ob = yb * SN
            for (k in 0 until SN) {
                val d = (a[oa + k].toInt() and 255) - (b[ob + k].toInt() and 255)
                sum += if (d < 0) -d else d
                if (sum > SN * 7) return false
            }
            return true
        }

        // cari pergeseran d (baris baru y == baris lama y+d) secara toleran. return d atau 0 kalau tidak ketemu
        private fun tolerantShift(sa: ByteArray, sb: ByteArray): Int {
            val infB = BooleanArray(h) { rowInf(sb, it) }
            var best = 0; var bs = -1e9; var bm = 0; var bn = 0
            val maxD = (h * 0.95f).toInt()
            for (d in 1 until maxD) {
                var m = 0; var x = 0
                var y = 0
                while (y < h - d) {
                    if (infB[y]) { if (rowEq(sb, y, sa, y + d)) m++ else x++ }
                    y += 2
                }
                val s = m - 1.5 * x
                if (s > bs) { bs = s; best = d; bm = m; bn = m + x }
            }
            if (best == 0 || bm < 10 || bm < bn * 0.6) return 0
            return best
        }

        // tepi kiri/kanan diabaikan supaya scrollbar yang muncul saat scroll tidak merusak pencocokan
        private fun hashes(b: Bitmap, inf: BooleanArray): LongArray {
            val ww = b.width; val hh = b.height
            val row = IntArray(ww)
            val r = LongArray(hh)
            val m = minOf(maxOf(ww / 30, 8), ww / 4)
            for (y in 0 until hh) {
                b.getPixels(row, 0, ww, 0, y, ww, 1)
                var hs = 1125899906842597L; val first = row[m] and 0xF8F8F8; var varied = false
                var x = m
                while (x < ww - m) {
                    val p = row[x] and 0xF8F8F8
                    if (p != first) varied = true
                    hs = hs * 31 + p
                    x += 3
                }
                r[y] = hs; inf[y] = varied
            }
            return r
        }

        private fun freq(a: LongArray): HashMap<Long, Int> {
            val m = HashMap<Long, Int>(a.size * 2)
            for (v in a) m[v] = (m[v] ?: 0) + 1
            return m
        }

        private fun crop(n: Bitmap, y: Int, len: Int): Bitmap {
            val o = Bitmap.createBitmap(n.width, len, Bitmap.Config.ARGB_8888)
            Canvas(o).drawBitmap(n, Rect(0, y, n.width, y + len), Rect(0, 0, n.width, len), null)
            return o
        }

        private fun setPrev(n: Bitmap) {
            val o = prev
            if (o != null && o !== n && !strips.contains(o)) o.recycle()
            prev = n
        }

        // return null kalau sukses, atau pesan error
        fun add(n: Bitmap): String? {
            if (strips.isEmpty()) {
                strips.add(n); w = n.width; h = n.height; total = h; accEnd = h
                val inf = BooleanArray(h); pHash = hashes(n, inf)
                pSig = sigs(n)
                prev = n
                return null
            }
            if (n.width != w || n.height != h) { n.recycle(); return "Ukuran layar berubah" }
            val ra = pHash!!
            val inf = BooleanArray(h)
            val rb = hashes(n, inf)
            var same = 0
            for (y in 0 until h) if (rb[y] == ra[y]) same++
            if (same > h * 0.97) { n.recycle(); return "Layar belum bergeser, scroll dulu" }

            // bobot tiap baris = 1 / berapa kali pola baris itu muncul. Baris yang berulang
            // (isi kartu/list yang seragam) tidak lagi mengalahkan baris unik (teks/gambar)
            val fa = freq(ra); val fb2 = freq(rb)
            val wt = DoubleArray(h)
            for (y in 0 until h) wt[y] = 1.0 / maxOf(fa[rb[y]] ?: 0, fb2[rb[y]] ?: 1)

            var best = 0; var bs = -1e18; var bm = 0.0; var bc = 0
            val maxD = (h * 0.92f).toInt()
            for (d in 1 until maxD) {
                var m = 0.0; var x = 0.0; var c = 0
                for (y in 0 until h - d) {
                    if (!inf[y]) continue
                    if (rb[y] == ra[y + d]) { m += wt[y]; c++ } else x += wt[y]
                }
                val s = m - x
                if (s > bs) { bs = s; best = d; bm = m; bc = c }
            }
            var sb: ByteArray? = null
            if (best == 0 || bc < 8 || bm < 1.5) {
                sb = sigs(n)
                best = tolerantShift(pSig!!, sb)
                if (best == 0) { n.recycle(); return "Gagal menyambung. Scroll balik sedikit ke atas (harus ada bagian yang sama dengan sebelumnya), lalu tekan kamera lagi" }
            }
            var fb = 0
            val cap = h / 4
            while (fb < cap && rb[h - 1 - fb] == ra[h - 1 - fb]) fb++
            val f = h - fb
            if (!trimmed) {
                val s0 = strips[0]
                val t = crop(s0, 0, f)
                strips[0] = t
                total = f; accEnd = f; trimmed = true
            }
            // kalau scroll lebih jauh dari bagian yang sudah tersimpan, ambil baris yang terlewat dari layar sebelumnya
            val gap = if (accEnd < best) best - accEnd else 0
            val start = maxOf(accEnd - best, 0)
            val len = f - start
            if (total + gap + maxOf(len, 0) > 30000) { n.recycle(); return "Batas tinggi screenshot tercapai" }
            if (gap > 0) {
                strips.add(crop(prev!!, accEnd, gap)); total += gap; accEnd = best
            }
            if (len > 0) {
                strips.add(crop(n, start, len)); total += len
            }
            accEnd = maxOf(f, accEnd - best)
            footer = if (fb > 0) crop(n, f, fb) else null
            pHash = rb
            pSig = sb ?: sigs(n)
            setPrev(n)
            return null
        }

        fun result(): Bitmap? {
            if (strips.isEmpty()) return null
            val f = footer
            if (strips.size == 1 && f == null) return strips[0]
            val th = total + (f?.height ?: 0)
            val out = Bitmap.createBitmap(w, th, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            var y = 0f
            for (s in strips) { c.drawBitmap(s, 0f, y, null); y += s.height }
            if (f != null) c.drawBitmap(f, 0f, y, null)
            return out
        }
    }

    fun writePng(b: Bitmap, f: File) {
        f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun save(c: Context, b: Bitmap, done: (String) -> Unit) {
        val ctx = c.applicationContext
        Thread {
            val msg = try {
                val sp = ctx.getSharedPreferences("sp", 0)
                val tree = Uri.parse(sp.getString("dir", null)!!)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                val n = sp.getInt("n", 0) + 1
                val uri = DocumentsContract.createDocument(ctx.contentResolver, parent, "image/png", "screenshot $n")!!
                ctx.contentResolver.openOutputStream(uri)!!.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                sp.edit().putInt("n", n).apply()
                "Tersimpan: screenshot $n"
            } catch (e: Exception) {
                "Gagal simpan: ${e.message}"
            }
            Handler(Looper.getMainLooper()).post { done(msg) }
        }.start()
    }
}
