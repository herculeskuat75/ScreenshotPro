package com.screenshotpro

import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.EditText
import kotlin.math.*

class EditorView(c: Context, val bmp: Bitmap) : View(c) {
    // type: 0 pena, 1 teks, 2 bulat, 3 panah, 4 kotak
    class Item(var type: Int, var x1: Float, var y1: Float, var color: Int) {
        var x2 = x1; var y2 = y1; var text = ""; var size = 0f
        val pts = ArrayList<Float>()
        fun copy(): Item {
            val n = Item(type, x1, y1, color)
            n.x2 = x2; n.y2 = y2; n.text = text; n.size = size; n.pts.addAll(pts)
            return n
        }
    }
    private class Snap(val items: List<Item>, val crop: RectF?)

    val items = ArrayList<Item>()
    private val hist = ArrayList<Snap>()
    private var pushed = false
    var sel: Item? = null
    var tool = 0
    var color = 0xFFE53935.toInt()
    var onTool: (() -> Unit)? = null
    var crop: RectF? = null
    var hd = 2f

    private val m = Matrix()
    private val inv = Matrix()
    private val sw = maxOf(5f, bmp.width / 110f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private var drag = -2 // -2 diam, -1 geser item, >=0 handle, -3 pan, -4 buat, -6 teks
    private var cur: Item? = null
    private var lx = 0f; private var ly = 0f; private var sx0 = 0f; private var sy0 = 0f
    private var moved = false
    private var multi = false
    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            m.postScale(d.scaleFactor, d.scaleFactor, d.focusX, d.focusY); invalidate(); return true
        }
    })

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = w.toFloat() / bmp.width
        m.setScale(s, s)
    }

    private fun map(x: Float, y: Float): FloatArray {
        m.invert(inv); val a = floatArrayOf(x, y); inv.mapPoints(a); return a
    }

    private fun sc(): Float { val v = FloatArray(9); m.getValues(v); return v[Matrix.MSCALE_X] }
    private fun tw(t: Item): Float { p.textSize = t.size; return p.measureText(t.text) }
    private fun rect(t: Item) = RectF(min(t.x1, t.x2), min(t.y1, t.y2), max(t.x1, t.x2), max(t.y1, t.y2))

    private fun drawItem(c: Canvas, t: Item) {
        p.color = t.color
        when (t.type) {
            0 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
                val q = t.pts; val path = Path()
                if (q.size >= 2) {
                    path.moveTo(q[0], q[1]); var i = 2
                    while (i < q.size) { path.lineTo(q[i], q[i + 1]); i += 2 }
                    if (q.size == 2) path.lineTo(q[0] + 0.1f, q[1])
                }
                c.drawPath(path, p)
            }
            1 -> { p.style = Paint.Style.FILL; p.textSize = t.size; c.drawText(t.text, t.x1, t.y1 + t.size, p) }
            2 -> { p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeCap = Paint.Cap.BUTT; c.drawOval(rect(t), p) }
            4 -> { p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeJoin = Paint.Join.MITER; c.drawRect(rect(t), p) }
            3 -> {
                val a = atan2(t.y2 - t.y1, t.x2 - t.x1); val hl = sw * 4f
                p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeCap = Paint.Cap.BUTT
                c.drawLine(t.x1, t.y1, t.x2 - hl * 0.8f * cos(a), t.y2 - hl * 0.8f * sin(a), p)
                val path = Path()
                path.moveTo(t.x2, t.y2)
                path.lineTo(t.x2 - hl * cos(a - 0.5f), t.y2 - hl * sin(a - 0.5f))
                path.lineTo(t.x2 - hl * cos(a + 0.5f), t.y2 - hl * sin(a + 0.5f))
                path.close()
                p.style = Paint.Style.FILL
                c.drawPath(path, p)
            }
        }
    }

    private fun handles(t: Item): List<FloatArray> = when (t.type) {
        3 -> listOf(floatArrayOf(0f, t.x1, t.y1), floatArrayOf(2f, t.x2, t.y2))
        2, 4 -> listOf(floatArrayOf(0f, t.x1, t.y1), floatArrayOf(1f, t.x2, t.y1), floatArrayOf(2f, t.x2, t.y2), floatArrayOf(3f, t.x1, t.y2))
        1 -> listOf(floatArrayOf(2f, t.x1 + tw(t), t.y1 + t.size * 1.25f))
        else -> emptyList()
    }

    private fun setHandle(t: Item, i: Int, x: Float, y: Float) {
        when (i) {
            0 -> { t.x1 = x; t.y1 = y }
            1 -> { t.x2 = x; t.y1 = y }
            2 -> if (t.type == 1) t.size = max(16f, (y - t.y1) / 1.25f) else { t.x2 = x; t.y2 = y }
            3 -> { t.x1 = x; t.y2 = y }
        }
    }

    private fun move(t: Item, dx: Float, dy: Float) {
        t.x1 += dx; t.y1 += dy; t.x2 += dx; t.y2 += dy
        for (i in t.pts.indices) t.pts[i] += if (i % 2 == 0) dx else dy
    }

    private fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax; val dy = by - ay
        val l = dx * dx + dy * dy
        val u = if (l == 0f) 0f else (((px - ax) * dx + (py - ay) * dy) / l).coerceIn(0f, 1f)
        return hypot(px - (ax + u * dx), py - (ay + u * dy))
    }

    private fun hit(t: Item, x: Float, y: Float, tol: Float): Boolean = when (t.type) {
        0 -> { var r = false; var i = 0; while (i < t.pts.size) { if (hypot(t.pts[i] - x, t.pts[i + 1] - y) < tol + sw) r = true; i += 2 }; r }
        1 -> x in (t.x1 - tol)..(t.x1 + tw(t) + tol) && y in (t.y1 - tol)..(t.y1 + t.size * 1.25f + tol)
        3 -> segDist(x, y, t.x1, t.y1, t.x2, t.y2) < tol + sw
        else -> rect(t).let { RectF(it.left - tol, it.top - tol, it.right + tol, it.bottom + tol).contains(x, y) }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.save()
        canvas.concat(m)
        canvas.drawBitmap(bmp, 0f, 0f, bp)
        for (t in items) drawItem(canvas, t)
        crop?.let { r ->
            val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat(); val k = 1f / sc()
            p.style = Paint.Style.FILL; p.color = 0x99000000.toInt()
            canvas.drawRect(0f, 0f, bw, r.top, p); canvas.drawRect(0f, r.bottom, bw, bh, p)
            canvas.drawRect(0f, r.top, r.left, r.bottom, p); canvas.drawRect(r.right, r.top, bw, r.bottom, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f * k; p.color = Color.WHITE
            canvas.drawRect(r, p)
            if (tool == 6) {
                val hs = cropHandles(r)
                for (i in 0..7) {
                    p.style = Paint.Style.FILL; p.color = Color.WHITE; canvas.drawCircle(hs[i * 2], hs[i * 2 + 1], 15f * k, p)
                    p.style = Paint.Style.STROKE; p.color = 0xFF1E88E5.toInt(); canvas.drawCircle(hs[i * 2], hs[i * 2 + 1], 15f * k, p)
                }
            }
        }
        sel?.let { s ->
            val k = 1f / sc()
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f * k; p.color = 0xFF1E88E5.toInt()
            if (s.type == 1) canvas.drawRect(s.x1, s.y1, s.x1 + tw(s), s.y1 + s.size * 1.25f, p)
            for (hd in handles(s)) {
                p.style = Paint.Style.FILL; p.color = Color.WHITE; canvas.drawCircle(hd[1], hd[2], 13f * k, p)
                p.style = Paint.Style.STROKE; p.color = 0xFF1E88E5.toInt(); canvas.drawCircle(hd[1], hd[2], 13f * k, p)
            }
        }
        canvas.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        if (e.pointerCount >= 2) {
            val cx = (e.getX(0) + e.getX(1)) / 2; val cy = (e.getY(0) + e.getY(1)) / 2
            if (multi) { m.postTranslate(cx - lx, cy - ly); invalidate() }
            multi = true; lx = cx; ly = cy; drag = -2
            return true
        }
        val x = e.x; val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false; moved = false; pushed = false; lx = x; ly = y; sx0 = x; sy0 = y; cur = null
                val q = map(x, y); val tol = 36f / sc()
                when (tool) {
                    0 -> {
                        drag = -3
                        sel?.let { s -> for (hd in handles(s)) if (hypot(hd[1] - q[0], hd[2] - q[1]) < tol * 1.3f) { drag = hd[0].toInt(); break } }
                        if (drag == -3) {
                            val f = items.lastOrNull { hit(it, q[0], q[1], tol) }
                            if (f != null) { sel = f; drag = -1 } else sel = null
                        }
                    }
                    1 -> { push(); val t = Item(0, q[0], q[1], color); t.pts.add(q[0]); t.pts.add(q[1]); items.add(t); cur = t; drag = -4; sel = null }
                    2 -> drag = -6
                    6 -> {
                        val cr = crop ?: RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat()).also { crop = it }
                        sel = null; drag = -3
                        val hs = cropHandles(cr)
                        for (i in 0..7) if (hypot(hs[i * 2] - q[0], hs[i * 2 + 1] - q[1]) < tol * 1.3f) { drag = 100 + i; break }
                        if (drag == -3 && cr.contains(q[0], q[1])) drag = 108
                    }
                    else -> { push(); val t = Item(tool - 1, q[0], q[1], color); items.add(t); cur = t; drag = -4; sel = null }
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (drag == -2) return true
                if (hypot(x - sx0, y - sy0) > 12f) moved = true
                if (!pushed && (drag == -1 || drag >= 0)) { push(); pushed = true }
                val q = map(x, y)
                when {
                    drag in 100..107 -> crop?.let { dragCrop(it, drag - 100, q[0], q[1]) }
                    drag == 108 -> { val a = map(lx, ly); crop?.let { moveCrop(it, q[0] - a[0], q[1] - a[1]) } }
                    drag == -3 -> m.postTranslate(x - lx, y - ly)
                    drag == -1 -> { val a = map(lx, ly); sel?.let { move(it, q[0] - a[0], q[1] - a[1]) } }
                    drag >= 0 -> sel?.let { setHandle(it, drag, q[0], q[1]) }
                    drag == -4 -> cur?.let { c -> if (c.type == 0) { c.pts.add(q[0]); c.pts.add(q[1]) } else { c.x2 = q[0]; c.y2 = q[1] } }
                }
                lx = x; ly = y; invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (drag == -6 && !moved) askText(map(x, y))
                val c = cur
                if (drag == -4 && c != null && c.type != 0) {
                    if (hypot(c.x2 - c.x1, c.y2 - c.y1) < 12f / sc()) { items.remove(c); if (hist.isNotEmpty()) hist.removeAt(hist.size - 1) }
                    else { sel = c; tool = 0; onTool?.invoke() }
                }
                drag = -2; cur = null; invalidate()
            }
        }
        return true
    }

    private fun askText(q: FloatArray) {
        val et = EditText(context)
        AlertDialog.Builder(context).setTitle("Teks").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val s = et.text.toString()
                if (s.isNotBlank()) {
                    push(); val t = Item(1, q[0], q[1], color); t.text = s; t.size = bmp.width / 18f
                    items.add(t); sel = t; tool = 0; onTool?.invoke(); invalidate()
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun push() {
        hist.add(Snap(items.map { it.copy() }, crop?.let { RectF(it) }))
        if (hist.size > 60) hist.removeAt(0)
    }

    fun undo() {
        if (hist.isEmpty()) return
        val s = hist.removeAt(hist.size - 1)
        items.clear(); items.addAll(s.items.map { it.copy() })
        crop = s.crop?.let { RectF(it) }
        sel = null; invalidate()
    }

    fun resetAll() {
        push()
        items.clear(); sel = null
        if (crop != null) startCrop()
        invalidate()
    }

    fun deleteSel() { sel?.let { push(); items.remove(it); sel = null; invalidate() } }
    fun setColorAll(c: Int) { color = c; sel?.let { push(); it.color = c }; invalidate() }

    private fun cropHandles(r: RectF) = floatArrayOf(
        r.left, r.top, r.centerX(), r.top, r.right, r.top, r.right, r.centerY(),
        r.right, r.bottom, r.centerX(), r.bottom, r.left, r.bottom, r.left, r.centerY()
    )

    private fun dragCrop(r: RectF, i: Int, x0: Float, y0: Float) {
        val x = x0.coerceIn(0f, bmp.width.toFloat()); val y = y0.coerceIn(0f, bmp.height.toFloat())
        if (i == 0 || i == 6 || i == 7) r.left = min(x, r.right - 40f)
        if (i == 2 || i == 3 || i == 4) r.right = max(x, r.left + 40f)
        if (i == 0 || i == 1 || i == 2) r.top = min(y, r.bottom - 40f)
        if (i == 4 || i == 5 || i == 6) r.bottom = max(y, r.top + 40f)
    }

    private fun moveCrop(r: RectF, dx: Float, dy: Float) {
        val w = r.width(); val h = r.height()
        val l = (r.left + dx).coerceIn(0f, bmp.width - w); val t = (r.top + dy).coerceIn(0f, bmp.height - h)
        r.set(l, t, l + w, t + h)
    }

    fun startCrop() { crop = RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat()); invalidate() }
    fun resetCrop() { crop = null; invalidate() }

    fun render(): Bitmap {
        val r = crop ?: RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat())
        var s = hd
        while (s > 1f && r.width() * s * r.height() * s > 40_000_000f) s -= 0.5f
        if (s < 1f) s = 1f
        val out = Bitmap.createBitmap((r.width() * s).roundToInt(), (r.height() * s).roundToInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.scale(s, s); cv.translate(-r.left, -r.top)
        cv.drawBitmap(bmp, 0f, 0f, bp)
        for (t in items) drawItem(cv, t)
        return out
    }
}
