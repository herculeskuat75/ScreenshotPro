package com.screenshotpro

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.widget.*

class EditorActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val bmp = BitmapFactory.decodeFile(intent.getStringExtra("p"))
        if (bmp == null) { finish(); return }
        val v = EditorView(this, bmp)
        v.setBackgroundColor(0xFF222222.toInt())
        val bar = LinearLayout(this)
        val tools = ArrayList<Button>()
        fun btn(t: String, a: (Button) -> Unit): Button {
            val b = Button(this)
            b.text = t; b.isAllCaps = false
            b.setOnClickListener { a(b) }
            bar.addView(b)
            return b
        }
        fun refresh() { tools.forEachIndexed { i, b -> b.alpha = if (i == v.tool) 1f else 0.5f } }
        listOf("Pilih", "Pena", "Teks", "Bulat", "Panah", "Kotak", "Potong").forEachIndexed { i, n ->
            tools.add(btn(n) { v.tool = i; refresh() })
        }
        val cols = intArrayOf(0xFFE53935.toInt(), 0xFFFDD835.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), Color.BLACK, Color.WHITE)
        var ci = 0
        val cb = btn("● Warna") { b -> ci = (ci + 1) % cols.size; v.setColorAll(cols[ci]); b.setTextColor(cols[ci]) }
        cb.setBackgroundColor(0xFF888888.toInt()); cb.setTextColor(cols[0])
        btn("Reset potong") { v.resetCrop() }
        btn("HD 2x") { b -> v.hd = when (v.hd) { 1f -> 2f; 2f -> 3f; else -> 1f }; b.text = "HD ${v.hd.toInt()}x" }
        btn("Hapus") { v.deleteSel() }
        btn("Simpan") { Util.save(this, v.render()) { m -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); if (m.startsWith("Tersimpan")) finish() } }
        btn("Tutup") { finish() }
        v.tool = 6; v.startCrop()
        v.onTool = { refresh() }
        refresh()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(v, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(HorizontalScrollView(this).apply { addView(bar) }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }
}
