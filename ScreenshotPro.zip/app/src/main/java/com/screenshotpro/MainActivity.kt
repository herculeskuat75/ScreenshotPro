package com.screenshotpro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pd = dp(20)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pd, pd * 2, pd, pd) }
        val sz = dp(150)
        val logo = FrameLayout(this)
        val ring = ImageView(this).apply { setImageResource(R.drawable.ring) }
        logo.addView(ring, FrameLayout.LayoutParams(sz, sz))
        logo.addView(ImageView(this).apply { setImageResource(R.drawable.logo_text) }, FrameLayout.LayoutParams(sz, sz))
        android.animation.ObjectAnimator.ofFloat(ring, "rotation", 0f, 360f).apply {
            duration = 4000; repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator(); start()
        }
        root.addView(logo, LinearLayout.LayoutParams(sz, sz).apply { gravity = Gravity.CENTER_HORIZONTAL })
        info = TextView(this).apply { setPadding(0, pd, 0, pd) }
        root.addView(info)
        fun lbl(p: Int) = "Durasi tahan tombol kamera: " + (if (p == 0) "0 (tahan tidak diperlukan)" else "${p / 10},${p % 10} detik")
        val dl = TextView(this).apply { text = lbl(prefs().getInt("delay", 0)) }
        root.addView(dl)
        root.addView(SeekBar(this).apply {
            max = 50; progress = prefs().getInt("delay", 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { dl.text = lbl(p); prefs().edit().putInt("delay", p).apply() }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })
        root.addView(TextView(this).apply { text = "0 detik: ditekan berapa lama pun langsung screenshot. Lebih dari 0: tombol harus ditahan sampai durasi terpenuhi, jika dilepas lebih awal tidak screenshot."; setPadding(0, 0, 0, pd) })
        fun slbl(p: Int) = "Kecepatan putaran lingkaran pelangi tombol: " + (if (p == 0) "berhenti" else "$p / 10")
        val sl = TextView(this).apply { text = slbl(prefs().getInt("spd", 5)) }
        root.addView(sl)
        root.addView(SeekBar(this).apply {
            max = 10; progress = prefs().getInt("spd", 5)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { sl.text = slbl(p); prefs().edit().putInt("spd", p).apply() }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })
        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() } })
        btn("Pilih folder penyimpanan") { pickDir() }
        btn("Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Aktifkan aksesibilitas (agar tombol muncul di Pengaturan & Opsi Developer)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("Aktifkan otomatis (khusus root)") { rootEnable() }
        btn("Mulai tombol kamera mengambang") { start() }
        btn("Hentikan") { stopService(Intent(this, FloatService::class.java)) }
        setContentView(ScrollView(this).apply { addView(root) })
        if (prefs().getString("dir", null) == null) pickDir()
    }

    override fun onResume() {
        super.onResume()
        val d = prefs().getString("dir", null)
        info.text = "Folder: " + (if (d == null) "belum dipilih" else Uri.decode(Uri.parse(d).lastPathSegment ?: d)) +
            "\nOverlay: " + (if (Settings.canDrawOverlays(this)) "diizinkan" else "belum diizinkan") +
            "\nAksesibilitas: " + (if (A11yService.inst != null) "aktif" else "belum aktif")
    }

    private fun rootEnable() {
        Thread {
            val id = "$packageName/$packageName.A11yService"
            val sc = "cur=\$(settings get secure enabled_accessibility_services); " +
                "case \"\$cur\" in *$packageName*) ;; \"\"|null) settings put secure enabled_accessibility_services $id;; " +
                "*) settings put secure enabled_accessibility_services \"\$cur:$id\";; esac; " +
                "settings put secure accessibility_enabled 1; appops set $packageName SYSTEM_ALERT_WINDOW allow"
            val ok = try { Runtime.getRuntime().exec(arrayOf("su", "-c", sc)).waitFor() == 0 } catch (e: Exception) { false }
            runOnUiThread {
                Toast.makeText(this, if (ok) "Berhasil (root)" else "Root tidak tersedia / ditolak", Toast.LENGTH_LONG).show()
                onResume()
            }
        }.start()
    }

    private fun prefs() = getSharedPreferences("sp", 0)

    private fun pickDir() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        startActivityForResult(i, 1)
    }

    private fun start() {
        if (prefs().getString("dir", null) == null) { pickDir(); return }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rs != RESULT_OK || d == null) return
        if (rq == 1) {
            val u = d.data ?: return
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs().edit().putString("dir", u.toString()).apply()
            onResume()
        } else if (rq == 2) {
            startForegroundService(Intent(this, FloatService::class.java).putExtra("code", rs).putExtra("data", d))
            Toast.makeText(this, "Tombol kamera aktif", Toast.LENGTH_SHORT).show()
        }
    }
}
