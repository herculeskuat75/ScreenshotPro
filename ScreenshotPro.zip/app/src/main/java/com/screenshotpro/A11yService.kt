package com.screenshotpro

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class A11yService : AccessibilityService() {
    companion object { var inst: A11yService? = null }

    override fun onServiceConnected() {
        inst = this
        try { FloatService.inst?.refreshOverlay() } catch (_: Exception) {}
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        inst = null
        try { FloatService.inst?.refreshOverlay() } catch (_: Exception) {}
        return super.onUnbind(i)
    }
}
