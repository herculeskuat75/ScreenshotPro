package com.screenshotpro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class A11yService : AccessibilityService() {
    companion object { var inst: A11yService? = null }

    override fun onServiceConnected() {
        inst = this
        try { FloatService.inst?.refreshOverlay() } catch (_: Exception) {}
    }
    // geser jari ke atas (scroll ke bawah) lalu berhenti dulu sebelum lepas supaya tidak ada fling
    fun swipeUp(x: Float, y1: Float, y2: Float, done: (Boolean) -> Unit) {
        val p1 = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        val p2 = Path().apply { moveTo(x, y2) }
        val s1 = GestureDescription.StrokeDescription(p1, 0, 300, true)
        val s2 = s1.continueStroke(p2, 0, 120, false)
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(s1).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                val ok2 = dispatchGesture(GestureDescription.Builder().addStroke(s2).build(), object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) { done(true) }
                    override fun onCancelled(g: GestureDescription?) { done(false) }
                }, null)
                if (!ok2) done(false)
            }
            override fun onCancelled(g: GestureDescription?) { done(false) }
        }, null)
        if (!ok) done(false)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        inst = null
        try { FloatService.inst?.refreshOverlay() } catch (_: Exception) {}
        return super.onUnbind(i)
    }
}
