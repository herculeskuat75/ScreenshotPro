package com.screenshotpro

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

class GlowView(c: Context) : View(c) {
    private var angle = 0f
    private var fade = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val mx = Matrix()
    private var sh: SweepGradient? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sh = SweepGradient(
            w / 2f, h / 2f,
            intArrayOf(0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF1744.toInt()),
            null
        )
    }

    override fun onDraw(c: Canvas) {
        val s = sh ?: return
        mx.setRotate(angle, width / 2f, height / 2f)
        s.setLocalMatrix(mx)
        p.shader = s
        val r = context.dp(36).toFloat()
        for ((w, a) in listOf(14 to 40, 9 to 90, 5 to 255)) {
            val sw = context.dp(w).toFloat()
            p.strokeWidth = sw
            p.alpha = (a * fade).toInt()
            val i = sw / 2
            c.drawRoundRect(i, i, width - i, height - i, r, r, p)
        }
    }

    fun play(onEnd: () -> Unit) {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            interpolator = LinearInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                angle = t * 720f
                fade = if (t > 0.7f) (1f - t) / 0.3f else 1f
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { onEnd() } })
            start()
        }
    }
}
