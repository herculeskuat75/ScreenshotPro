package com.example.customscreenshot

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

object BitmapUtils {

    class StitchResult(val bitmap: Bitmap, val scrolled: Boolean, val matched: Boolean)

    // ---------- CAPTURE (root) ----------
    fun captureScreen(): Bitmap? = try {
        val pb = ProcessBuilder("su", "-c", "screencap -p")
        pb.redirectError(ProcessBuilder.Redirect.DISCARD)
        val p = pb.start()
        val bytes = p.inputStream.readBytes()
        p.waitFor()
        if (bytes.size < 100) null else BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (_: Throwable) { null }

    fun swipeUp(w: Int, h: Int) {
        try {
            val x = w / 2
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "input swipe $x ${(h * 0.80f).toInt()} $x ${(h * 0.30f).toInt()} 700"))
            p.waitFor()
        } catch (_: Throwable) {}
    }

    // ---------- STITCHING ----------
    fun stitchBitmaps(bitmap1: Bitmap, bitmap2: Bitmap): Bitmap = stitchResult(bitmap1, bitmap2).bitmap

    private class Sig(val b: Bitmap, val xs: IntArray) {
        private val rows = arrayOfNulls<IntArray>(b.height)
        private val buf = IntArray(b.width)
        fun row(y: Int): IntArray {
            rows[y]?.let { return it }
            b.getPixels(buf, 0, b.width, 0, y, b.width, 1)
            val r = IntArray(xs.size) { buf[xs[it]] }
            rows[y] = r
            return r
        }
    }

    // fraksi sampel piksel yang BERBEDA antara dua baris (0 = identik)
    private fun mism(a: IntArray, b: IntArray): Float {
        var c = 0
        for (i in a.indices) {
            val p = a[i]; val q = b[i]
            val d = abs(((p shr 16) and 255) - ((q shr 16) and 255)) +
                    abs(((p shr 8) and 255) - ((q shr 8) and 255)) +
                    abs((p and 255) - (q and 255))
            if (d > 48) c++
        }
        return c.toFloat() / a.size
    }

    private fun isUniform(r: IntArray): Boolean {
        val f = r[0]; var diff = 0
        for (i in 1 until r.size) {
            val q = r[i]
            val d = abs(((f shr 16) and 255) - ((q shr 16) and 255)) +
                    abs(((f shr 8) and 255) - ((q shr 8) and 255)) +
                    abs((f and 255) - (q and 255))
            if (d > 48 && ++diff >= 3) return false
        }
        return true
    }

    // ukuran header/footer yang TETAP (identik di dua gambar), toleran terhadap jam/ikon yang berubah
    private fun fixedEdge(a: Sig, b: Sig, h1: Int, h2: Int, fromBottom: Boolean, maxRows: Int): Int {
        val gap = 40
        var last = -1
        var i = 0
        while (i < maxRows) {
            val y1 = if (fromBottom) h1 - 1 - i else i
            val y2 = if (fromBottom) h2 - 1 - i else i
            val ra = a.row(y1)
            val ok = !isUniform(ra) && mism(ra, b.row(y2)) <= 0.03f
            if (ok) {
                if (last == -1 && i > 120) break
                last = i
            } else if (last == -1 && i > 120) break
            else if (last != -1 && i - last > gap) break
            i++
        }
        return last + 1
    }

    fun stitchResult(b1: Bitmap, b2raw: Bitmap): StitchResult {
        val b2 = if (b2raw.width != b1.width)
            Bitmap.createScaledBitmap(b2raw, b1.width, max(1, b2raw.height * b1.width / b2raw.width), true) else b2raw
        val w = b1.width; val h1 = b1.height; val h2 = b2.height
        val xs = IntArray(w / 3) { it * 3 }
        val a = Sig(b1, xs); val b = Sig(b2, xs)

        val headerH = fixedEdge(a, b, h1, h2, false, (h2 * 0.35f).toInt())
        val footerH = fixedEdge(a, b, h1, h2, true, (h2 * 0.25f).toInt())
        val end1 = h1 - footerH
        val end2 = h2 - footerH
        val contentH2 = end2 - headerH
        if (contentH2 < 80) return concatFallback(b1, b2, w, headerH)

        val t = (contentH2 / 5).coerceIn(48, 300).coerceAtMost(contentH2)
        var bestScore = Float.MAX_VALUE
        var bestTs = -1; var bestY1 = -1

        var ts = headerH
        while (ts + t <= end2 && ts - headerH <= contentH2 * 0.7f) {
            // baris bertekstur dalam template (maks 120, merata)
            val tex = ArrayList<Int>()
            for (k in 0 until t) if (!isUniform(b.row(ts + k))) tex.add(k)
            if (tex.size >= t * 0.35f) {
                val rowsUsed = if (tex.size > 120) { val st = tex.size / 120.0f; List(120) { tex[(it * st).toInt()] } } else tex
                val lo = max(ts, max(headerH, end1 - 2 * h2))
                var y1 = lo
                while (y1 <= end1 - t) {
                    var sum = 0f
                    val cutoff = if (bestScore == Float.MAX_VALUE) Float.MAX_VALUE else bestScore * rowsUsed.size
                    var aborted = false
                    for (k in rowsUsed) {
                        sum += mism(a.row(y1 + k), b.row(ts + k))
                        if (sum > cutoff) { aborted = true; break }
                    }
                    if (!aborted) {
                        val sc = sum / rowsUsed.size
                        if (sc < bestScore) { bestScore = sc; bestTs = ts; bestY1 = y1 }
                    }
                    y1++
                }
                if (bestScore <= 0.003f) break
            }
            ts += max(1, t / 2)
        }

        if (bestTs < 0 || bestScore > 0.04f) return concatFallback(b1, b2, w, headerH)

        // baris b2 yang sejajar dengan baris end1 milik b1
        val r1 = bestTs + (end1 - bestY1)
        if (r1 >= end2) return StitchResult(b1, false, true) // tidak ada konten baru (ujung halaman)

        val outH = end1 + (h2 - r1)
        val out = Bitmap.createBitmap(w, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(b1, Rect(0, 0, w, end1), Rect(0, 0, w, end1), null)
        c.drawBitmap(b2, Rect(0, r1, w, h2), Rect(0, end1, w, outH), null)
        return StitchResult(out, true, true)
    }

    private fun concatFallback(b1: Bitmap, b2: Bitmap, w: Int, headerH: Int): StitchResult {
        val cut = headerH.coerceIn(0, b2.height - 1)
        val outH = b1.height + (b2.height - cut)
        val out = Bitmap.createBitmap(w, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(b1, 0f, 0f, null)
        c.drawBitmap(b2, Rect(0, cut, w, b2.height), Rect(0, b1.height, w, outH), null)
        return StitchResult(out, true, false)
    }

    // ---------- SIMPAN KE GALERI (MediaStore) ----------
    fun saveToGallery(ctx: Context, bmp: Bitmap, prefix: String): Uri? {
        val name = "${prefix}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.png"
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CustomScreenshot")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                v.clear(); v.put(MediaStore.Images.Media.IS_PENDING, 0)
                ctx.contentResolver.update(uri, v, null, null)
                uri
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "CustomScreenshot")
                dir.mkdirs()
                val f = File(dir, name)
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf("image/png"), null)
                Uri.fromFile(f)
            }
        } catch (_: Throwable) { null }
    }
}
