package com.example.customscreenshot
import android.content.Intent
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF121212)) { ScreenshotConfigScreen() } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenshotConfigScreen() {
    val context = LocalContext.current
    var screenLength by remember { mutableFloatStateOf(3f) }
    var isAutoMode by remember { mutableStateOf(true) }
    var isRainbowEffectEnabled by remember { mutableStateOf(true) }
    var captureSpeed by remember { mutableFloatStateOf(1.0f) }
    var isRootAvailable by remember { mutableStateOf(false) }
    var hasOverlayPermission by remember { mutableStateOf(false) }
    var storageFolderUri by remember { mutableStateOf<Uri?>(null) }

    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { hasOverlayPermission = Settings.canDrawOverlays(context) }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { storageFolderUri = it; context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
    }

    LaunchedEffect(Unit) {
        isRootAvailable = checkRootAccess()
        hasOverlayPermission = Settings.canDrawOverlays(context)
        if (isRootAvailable && !hasOverlayPermission) {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "appops set ${context.packageName} SYSTEM_ALERT_WINDOW allow"))
                    p.waitFor() == 0
                } catch (_: Exception) { false }
            }
            if (ok) hasOverlayPermission = true
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Kustom Long Screenshot", color = Color.White) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1E1E1E))) },
        containerColor = Color(0xFF121212)
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxSize().padding(paddingValues).verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            RainbowCameraLogo(isRainbowActive = isRainbowEffectEnabled)
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Status Sistem & Izin", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Root Access (`su`):", color = Color.LightGray)
                        Text(text = if (isRootAvailable) "Terdeteksi" else "Tidak Ada", color = if (isRootAvailable) Color(0xFF4CAF50) else Color(0xFFFF5252), fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Izin Overlay Layar:", color = Color.LightGray)
                        if (hasOverlayPermission) Text("Diberikan", color = Color(0xFF4CAF50), fontWeight = FontWeight.SemiBold)
                        else Button(onClick = { overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)), shape = RoundedCornerShape(8.dp)) { Text("Izinkan", fontSize = 12.sp) }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Folder Penyimpanan:", color = Color.LightGray)
                        OutlinedButton(onClick = { folderLauncher.launch(null) }, shape = RoundedCornerShape(8.dp)) { Text(text = if (storageFolderUri != null) "Terpilih" else "Pilih Folder", fontSize = 12.sp, color = Color.Cyan) }
                    }
                }
            }
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Konfigurasi Screenshot", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Panjang Screenshot: ${screenLength.roundToInt()} Layar", color = Color.White)
                    Slider(value = screenLength, onValueChange = { screenLength = it }, valueRange = 1f..10f, steps = 8)
                    Divider(color = Color(0xFF2C2C2C), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = if (isAutoMode) "Mode: Auto-Scroll" else "Mode: Manual Step", color = Color.White)
                        Switch(checked = isAutoMode, onCheckedChange = { isAutoMode = it })
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Efek Visual Rainbow", color = Color.White)
                        Switch(checked = isRainbowEffectEnabled, onCheckedChange = { isRainbowEffectEnabled = it })
                    }
                    Divider(color = Color(0xFF2C2C2C), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Kecepatan Pengambilan: ${"%.1f".format(captureSpeed)}x", color = Color.White)
                    Slider(value = captureSpeed, onValueChange = { captureSpeed = it }, valueRange = 0.5f..3.0f)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    if (!Settings.canDrawOverlays(context)) Toast.makeText(context, "Berikan izin overlay terlebih dahulu!", Toast.LENGTH_SHORT).show()
                    else {
                        Toast.makeText(context, "Memulai Overlay...", Toast.LENGTH_SHORT).show()
                        val intent = Intent(context, FloatingService::class.java).putExtra("screenLength", screenLength.roundToInt()).putExtra("auto", isAutoMode).putExtra("speed", captureSpeed)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676), contentColor = Color.Black)
            ) { Text("Mulai Tombol Melayang", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun RainbowCameraLogo(modifier: Modifier = Modifier, isRainbowActive: Boolean = true) {
    val infiniteTransition = rememberInfiniteTransition(label = "RainbowRotation")
    val rotationAngle by infiniteTransition.animateFloat(initialValue = 0f, targetValue = 360f, animationSpec = infiniteRepeatable(animation = tween(durationMillis = 3500, easing = LinearEasing)), label = "Rotation")
    val rainbowColors = listOf(Color(0xFFFF0055), Color(0xFFFF7700), Color(0xFFFFEB3B), Color(0xFF00E676), Color(0xFF00E5FF), Color(0xFF2979FF), Color(0xFFD500F9), Color(0xFFFF0055))
    Box(modifier = modifier.size(160.dp).padding(8.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val ringRadius = size.minDimension / 2 - 12.dp.toPx()
            if (isRainbowActive) {
                rotate(degrees = rotationAngle, pivot = center) { drawCircle(brush = Brush.sweepGradient(rainbowColors, center = center), radius = ringRadius, center = center, style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)) }
            } else {
                drawCircle(color = Color.DarkGray, radius = ringRadius, center = center, style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round))
            }
            val camWidth = size.width * 0.42f; val camHeight = size.height * 0.30f
            val camLeft = center.x - (camWidth / 2f); val camTop = center.y - (camHeight / 2f) + 4.dp.toPx()
            val ridgeWidth = camWidth * 0.35f; val ridgeHeight = 8.dp.toPx(); val ridgeLeft = center.x - (ridgeWidth / 2f)
            drawRoundRect(color = Color.White, topLeft = Offset(ridgeLeft, camTop - ridgeHeight + 2f), size = Size(ridgeWidth, ridgeHeight), cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()))
            drawRoundRect(color = Color.White, topLeft = Offset(camLeft, camTop), size = Size(camWidth, camHeight), cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx()))
            val lensCenter = Offset(center.x, camTop + (camHeight / 2f))
            drawCircle(color = Color(0xFF1E1E1E), radius = camHeight * 0.34f, center = lensCenter)
            drawCircle(color = if (isRainbowActive) Color(0xFF00E5FF) else Color.Gray, radius = camHeight * 0.18f, center = lensCenter)
            drawCircle(color = Color(0xFFFF5252), radius = 3.dp.toPx(), center = Offset(camLeft + camWidth - 10.dp.toPx(), camTop + 10.dp.toPx()))
        }
    }
}

private fun checkRootAccess(): Boolean {
    val paths = arrayOf("/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su")
    for (path in paths) { if (File(path).exists()) return true }
    return try { val process = Runtime.getRuntime().exec(arrayOf("which", "su")); process.waitFor() == 0 } catch (_: Exception) { false }
}
