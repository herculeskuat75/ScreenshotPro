package com.example.customscreenshot
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.delay

enum class EdgeStyle { MATI, SIMPLE, GRADIENT, MEWAH }

class FloatingService : LifecycleService(), ViewModelStoreOwner, SavedStateRegistryOwner {
    private val mViewModelStore = ViewModelStore()
    override val viewModelStore: ViewModelStore get() = mViewModelStore
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    private lateinit var windowManager: WindowManager
    private var floatingView: ComposeView? = null
    private var overlayView: ComposeView? = null
    private lateinit var floatingParams: WindowManager.LayoutParams
    private lateinit var overlayParams: WindowManager.LayoutParams
    private var selectedEdgeStyle by mutableStateOf(EdgeStyle.MEWAH)

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(Bundle())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()
        setupFloatingButton()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "floating_screenshot_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Layanan Tombol Melayang", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Screenshot Melayang Aktif").setContentText("Ketuk tombol melayang untuk menangkap layar.")
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }
        else { startForeground(1001, notification) }
    }

    private fun setupFloatingButton() {
        floatingParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 100; y = 300 }
        floatingView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindowOrReleasedFromPool)
            setViewTreeLifecycleOwner(this@FloatingService); setViewTreeViewModelStoreOwner(this@FloatingService); setViewTreeSavedStateRegistryOwner(this@FloatingService)
            setContent { FloatingRainbowButton(onDrag = { dx, dy -> floatingParams.x += dx.toInt(); floatingParams.y += dy.toInt(); windowManager.updateViewLayout(this, floatingParams) }, onClick = { triggerCaptureFlow() }) }
        }
        windowManager.addView(floatingView, floatingParams)
    }

    private fun triggerCaptureFlow() {
        if (overlayView != null) return
        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        )
        overlayView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindowOrReleasedFromPool)
            setViewTreeLifecycleOwner(this@FloatingService); setViewTreeViewModelStoreOwner(this@FloatingService); setViewTreeSavedStateRegistryOwner(this@FloatingService)
            setContent {
                CaptureOverlayContent(style = selectedEdgeStyle, onAnimationFinish = { makeOverlayTouchable() },
                    onActionSimpan = { Toast.makeText(applicationContext, "Tersimpan!", Toast.LENGTH_SHORT).show(); dismissOverlay() },
                    onActionEdit = { Toast.makeText(applicationContext, "Buka Editor...", Toast.LENGTH_SHORT).show(); dismissOverlay() },
                    onActionScreenshotPanjang = { Toast.makeText(applicationContext, "Auto-Scroll...", Toast.LENGTH_SHORT).show(); dismissOverlay() },
                    onDismiss = { dismissOverlay() }
                )
            }
        }
        windowManager.addView(overlayView, overlayParams)
    }

    private fun makeOverlayTouchable() { overlayView?.let { overlayParams.flags = overlayParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv(); windowManager.updateViewLayout(it, overlayParams) } }
    private fun dismissOverlay() { overlayView?.let { windowManager.removeView(it); overlayView = null } }
    override fun onDestroy() { super.onDestroy(); floatingView?.let { windowManager.removeView(it) }; overlayView?.let { windowManager.removeView(it) } }
}

@Composable
fun FloatingRainbowButton(onDrag: (Float, Float) -> Unit, onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "RainbowSpin")
    val rotation by infiniteTransition.animateFloat(0f, 360f, infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "Rot")
    val rainbowColors = listOf(Color(0xFFFF1744), Color(0xFFFF9100), Color(0xFFFFEA00), Color(0xFF00E676), Color(0xFF00E5FF), Color(0xFF2979FF), Color(0xFFD500F9), Color(0xFFFF1744))
    Box(modifier = Modifier.size(68.dp).pointerInput(Unit) { detectDragGestures { change, dragAmount -> change.consume(); onDrag(dragAmount.x, dragAmount.y) } }.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f); val ringRadius = (size.minDimension / 2f) - 6.dp.toPx()
            rotate(rotation, pivot = center) { drawCircle(Brush.sweepGradient(rainbowColors, center = center), ringRadius, center, style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)) }
            drawCircle(Color(0xFF1E1E1E), ringRadius - 4.dp.toPx(), center)
            val camWidth = 24.dp.toPx(); val camHeight = 17.dp.toPx()
            val camLeft = center.x - (camWidth / 2f); val camTop = center.y - (camHeight / 2f) + 2.dp.toPx()
            drawRoundRect(Color.White, Offset(center.x - 4.dp.toPx(), camTop - 3.dp.toPx()), Size(8.dp.toPx(), 4.dp.toPx()), CornerRadius(2.dp.toPx(), 2.dp.toPx()))
            drawRoundRect(Color.White, Offset(camLeft, camTop), Size(camWidth, camHeight), CornerRadius(4.dp.toPx(), 4.dp.toPx()))
            drawCircle(Color(0xFF1E1E1E), 5.dp.toPx(), Offset(center.x, camTop + (camHeight / 2f)))
            drawCircle(Color(0xFF00E5FF), 2.5.dp.toPx(), Offset(center.x, camTop + (camHeight / 2f)))
        }
    }
}

@Composable
fun CaptureOverlayContent(style: EdgeStyle, onAnimationFinish: () -> Unit, onActionSimpan: () -> Unit, onActionEdit: () -> Unit, onActionScreenshotPanjang: () -> Unit, onDismiss: () -> Unit) {
    var animationProgress by remember { mutableFloatStateOf(1f) }
    var showMenu by remember { mutableStateOf(false) }
    val infiniteTransition = rememberInfiniteTransition(label = "EdgeGradientAnim")
    val borderRotation by infiniteTransition.animateFloat(0f, 360f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "BorderRot")
    val fadeOutAlpha by animateFloatAsState(targetValue = animationProgress, animationSpec = tween(1000, easing = FastOutSlowInEasing), label = "Fade", finishedListener = { showMenu = true; onAnimationFinish() })
    LaunchedEffect(Unit) { delay(400); animationProgress = 0f }
    Box(modifier = Modifier.fillMaxSize().background(if (showMenu) Color.Black.copy(alpha = 0.55f) else Color.Transparent).clickable(enabled = showMenu) { onDismiss() }, contentAlignment = Alignment.Center) {
        if (fadeOutAlpha > 0.01f && style != EdgeStyle.MATI) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = when (style) { EdgeStyle.SIMPLE -> 6.dp.toPx(); EdgeStyle.GRADIENT -> 10.dp.toPx(); EdgeStyle.MEWAH -> 14.dp.toPx(); else -> 0f }
                val inset = strokeWidth / 2f; val rectSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                val topLeft = Offset(inset, inset); val center = Offset(size.width / 2f, size.height / 2f)
                when (style) {
                    EdgeStyle.SIMPLE -> drawRoundRect(Color.White.copy(alpha = fadeOutAlpha), topLeft, rectSize, CornerRadius(24.dp.toPx()), style = Stroke(strokeWidth))
                    EdgeStyle.GRADIENT -> { val brush = Brush.sweepGradient(listOf(Color(0xFF00E5FF).copy(alpha = fadeOutAlpha), Color(0xFFD500F9).copy(alpha = fadeOutAlpha), Color(0xFFFF1744).copy(alpha = fadeOutAlpha), Color(0xFF00E5FF).copy(alpha = fadeOutAlpha)), center); rotate(borderRotation, pivot = center) { drawRoundRect(brush, topLeft, rectSize, CornerRadius(28.dp.toPx()), style = Stroke(strokeWidth, cap = StrokeCap.Round)) } }
                    EdgeStyle.MEWAH -> { val neon = listOf(Color(0xFFFF0055).copy(alpha = fadeOutAlpha), Color(0xFFFF7700).copy(alpha = fadeOutAlpha), Color(0xFFFFEA00).copy(alpha = fadeOutAlpha), Color(0xFF00E676).copy(alpha = fadeOutAlpha), Color(0xFF00E5FF).copy(alpha = fadeOutAlpha), Color(0xFF7C4DFF).copy(alpha = fadeOutAlpha), Color(0xFFFF0055).copy(alpha = fadeOutAlpha)); drawRoundRect(Color(0xFF00E5FF).copy(alpha = fadeOutAlpha * 0.35f), Offset(inset / 2f, inset / 2f), Size(size.width - inset, size.height - inset), CornerRadius(32.dp.toPx()), style = Stroke(strokeWidth * 1.8f)); rotate(borderRotation, pivot = center) { drawRoundRect(Brush.sweepGradient(neon, center), topLeft, rectSize, CornerRadius(28.dp.toPx()), style = Stroke(strokeWidth, cap = StrokeCap.Round)) } }
                    else -> {}
                }
            }
        }
        AnimatedVisibility(visible = showMenu, enter = fadeIn(tween(300)) + scaleIn(tween(300))) {
            Card(modifier = Modifier.wrapContentSize().padding(24.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), elevation = CardDefaults.cardElevation(12.dp)) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Tangkapan Layar Berhasil", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = onActionSimpan, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)), shape = RoundedCornerShape(10.dp)) { Text("Simpan", color = Color.Black, fontWeight = FontWeight.SemiBold) }
                        Button(onClick = onActionEdit, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)), shape = RoundedCornerShape(10.dp)) { Text("Edit", color = Color.Black, fontWeight = FontWeight.SemiBold) }
                        Button(onClick = onActionScreenshotPanjang, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9100)), shape = RoundedCornerShape(10.dp)) { Text("Panjang", color = Color.Black, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }
    }
}
